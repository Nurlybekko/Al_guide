import { Component } from '@angular/core';

@Component({
  selector: 'app-asd',
  imports: [],
  templateUrl: './asd.component.html',
  styleUrl: './asd.component.css'
})
export class AsdComponent {

}
